
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'blinky_FreeRTOS_pca10040' 
 * Target:  'nrf52832_xxaa' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "nrf.h"

#define BSP_DEFINES_ONLY
#define CLOCK_ENABLED
#define FREERTOS
  #define configUSE_PORT_OPTIMISED_TASK_SELECTION
#define UART0_ENABLED

#endif /* RTE_COMPONENTS_H */
